package com.cinereservashd.aplicacion;

import view.VentanaPrincipal;

import javax.swing.SwingUtilities;


public class MainApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            VentanaPrincipal ventana = new VentanaPrincipal();
            ventana.setVisible(true);
        });
    }
}