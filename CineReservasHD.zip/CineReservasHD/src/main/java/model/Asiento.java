package model;

public class Asiento {
    private int fila;
    private int columna;
    private String estado; //Libre, Ocupado, Desactivado

    public int getFila() {
        return fila;
    }

    public int getColumna() {
        return columna;
    }

    public String getEstado() {
        return estado;
    }

    public void setFila(int fila) {
        this.fila = fila;
    }

    public void setColumna(int columna) {
        this.columna = columna;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    public void ocupar(){
        if (null == this.estado) {
            System.out.println("El estado no es valido");
        } else switch (this.estado) {
            case "Libre" -> {
                setEstado("Ocupado");
                System.out.println("Se ha ocupado el asiento con fila: " + this.getColumna() + "y columna: " + this.columna);
            }
            case "Desactivado" -> System.out.println("No se puede ocupar el asiento ya que esta desactivado");
            case "Ocupado" -> System.out.println("No se puede ocupar ya que el asiento ya se encuentra ocupado");
            default -> System.out.println("El estado no es valido");
        }
    }
    
    public void liberar(){
        if (null == this.estado) {
            System.out.println("El estado no es valido");
        } else switch (this.estado) {
            case "Ocupado" -> {
                setEstado("Libre");
                System.out.println("Se ha liberado el asiento con fila: " + this.getColumna() + "y columna: " + this.columna);
            }
            case "Desactivado" -> System.out.println("No se puede liberar el asiento ya que esta desactivado");
            case "Libre" -> System.out.println("No se puede liberar ya que el asiento ya se encuentra libre");
            default -> System.out.println("El estado no es valido");
        }
    }
    
    public boolean isOcupado(){
        return "Ocupado".equals(getEstado());
    }
    
    public boolean isDesactivado(){
        return "Desactivado".equals(getEstado());
    }
    
}
