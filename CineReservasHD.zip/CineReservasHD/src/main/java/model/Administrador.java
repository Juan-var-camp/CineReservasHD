package model;

public class Administrador extends Usuario{

    public Administrador(String username, String password, String nombre) {
        super(username, password, nombre);
    }
    
    public void gestionarPeliculas(Pelicula pelicula, String accion){
        
    }
    
    public void gestionarFunciones(Funcion funcion, String accion){
        
    }
    
    public void generarReportes(){
        
    }
    
}
