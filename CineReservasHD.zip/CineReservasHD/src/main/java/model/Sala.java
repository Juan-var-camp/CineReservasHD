package model;

public class Sala {
    private int id;
    private String nombre;
    private Asiento[][] asientos;

    public Sala() {}

    public Sala(int id, String nombre, Asiento[][] asientos) {
        this.id = id;
        this.nombre = nombre;
        this.asientos = asientos;
    }

    public Sala(String nombre, Asiento[][] asientos) {
        this.nombre = nombre;
        this.asientos = asientos;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Asiento[][] getAsientos() {
        return asientos;
    }

    public void setAsientos(Asiento[][] asientos) {
        this.asientos = asientos;
    }
}
