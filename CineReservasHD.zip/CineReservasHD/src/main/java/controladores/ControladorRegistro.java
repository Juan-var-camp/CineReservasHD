package controladores;

public class ControladorRegistro {
    
    public void llamadaControlador(){
    
    }
    
}
