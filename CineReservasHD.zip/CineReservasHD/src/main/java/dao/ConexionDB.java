package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionDB {

    private static final String URL = "jdbc:sqlite:src/main/resources/cinereservas.db";

    public static Connection conectar() throws SQLException {
        try {
            Connection conn = DriverManager.getConnection(URL);
            System.out.println("Conexión establecida con SQLite");
            return conn;
        } catch (SQLException e) {
            System.err.println("Error al conectar a la base de datos: " + e.getMessage());
            throw e;
        }
    }
}
