package view;

import dao.PeliculaDAO;
import model.Pelicula;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class PanelPeliculas extends JPanel {

    private JTable tabla;
    private DefaultTableModel modelo;
    private JTextField txtTitulo, txtGenero, txtDuracion;
    private JButton btnAgregar, btnEditar, btnEliminar, btnActualizar;
    private PeliculaDAO peliculaDAO;

    public PanelPeliculas() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        try {
            peliculaDAO = new PeliculaDAO(util.DataBaseConnection.getConnection());
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al conectar con la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // ---- Panel de formulario ----
        JPanel panelForm = new JPanel(new GridLayout(2, 4, 10, 10));
        panelForm.setBorder(BorderFactory.createTitledBorder("Datos de la Película"));
        panelForm.add(new JLabel("Título:"));
        txtTitulo = new JTextField();
        panelForm.add(txtTitulo);

        panelForm.add(new JLabel("Género:"));
        txtGenero = new JTextField();
        panelForm.add(txtGenero);

        panelForm.add(new JLabel("Duración (min):"));
        txtDuracion = new JTextField();
        panelForm.add(txtDuracion);

        btnAgregar = new JButton("Agregar");
        btnEditar = new JButton("Editar");
        btnEliminar = new JButton("Eliminar");
        btnActualizar = new JButton("Actualizar Lista");

        panelForm.add(btnAgregar);
        panelForm.add(btnEditar);
        panelForm.add(btnEliminar);
        panelForm.add(btnActualizar);

        // ---- Tabla ----
        modelo = new DefaultTableModel(new Object[]{"ID", "Título", "Género", "Duración"}, 0);
        tabla = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tabla);

        add(panelForm, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);

        cargarPeliculas();

        // ---- Listeners ----
        btnAgregar.addActionListener(e -> agregarPelicula());
        btnEditar.addActionListener(e -> editarPelicula());
        btnEliminar.addActionListener(e -> eliminarPelicula());
        btnActualizar.addActionListener(e -> cargarPeliculas());
    }

    private void cargarPeliculas() {
        try {
            modelo.setRowCount(0);
            List<Pelicula> lista = peliculaDAO.listar();
            for (Pelicula p : lista) {
                modelo.addRow(new Object[]{p.getId(), p.getTitulo(), p.getGenero(), p.getDuracion()});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar las películas", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void agregarPelicula() {
        try {
            String titulo = txtTitulo.getText();
            String genero = txtGenero.getText();
            int duracion = Integer.parseInt(txtDuracion.getText());

            peliculaDAO.insertar(new Pelicula(titulo, genero, duracion));
            cargarPeliculas();
            limpiarCampos();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Datos inválidos o error al agregar", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void editarPelicula() {
        int fila = tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una película para editar", "Atención", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            int id = (int) modelo.getValueAt(fila, 0);
            String titulo = txtTitulo.getText();
            String genero = txtGenero.getText();
            int duracion = Integer.parseInt(txtDuracion.getText());

            peliculaDAO.actualizar(new Pelicula(id, titulo, genero, duracion));
            cargarPeliculas();
            limpiarCampos();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al editar la película", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarPelicula() {
        int fila = tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una película para eliminar", "Atención", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "¿Eliminar esta película?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                int id = (int) modelo.getValueAt(fila, 0);
                peliculaDAO.eliminar(id);
                cargarPeliculas();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error al eliminar", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void limpiarCampos() {
        txtTitulo.setText("");
        txtGenero.setText("");
        txtDuracion.setText("");
    }
}


