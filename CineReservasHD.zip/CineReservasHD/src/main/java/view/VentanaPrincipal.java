package view;

import javax.swing.*;
import java.awt.*;

public class VentanaPrincipal extends JFrame {
    
    private JPanel panelCentral;
    
    public VentanaPrincipal() {
        setTitle("CineReservasHD");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);

        // Barra superior (menú o botones)
        JPanel panelSuperior = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelSuperior.setBackground(new Color(40, 40, 40));

        JButton btnPeliculas = new JButton("Películas");
        JButton btnSalas = new JButton("Salas");
        JButton btnFunciones = new JButton("Funciones");
        JButton btnReservas = new JButton("Reservas");
        JButton btnUsuarios = new JButton("Usuarios");

        panelSuperior.add(btnPeliculas);
        panelSuperior.add(btnSalas);
        panelSuperior.add(btnFunciones);
        panelSuperior.add(btnReservas);
        panelSuperior.add(btnUsuarios);

        // Panel central (donde se cambiarán los módulos)
        panelCentral = new JPanel();
        panelCentral.setLayout(new BorderLayout());
        panelCentral.add(new JLabel("Bienvenido a CineReservasHD", SwingConstants.CENTER), BorderLayout.CENTER);

        // Añadir todo al frame
        setLayout(new BorderLayout());
        add(panelSuperior, BorderLayout.NORTH);
        add(panelCentral, BorderLayout.CENTER);

        // Listeners para cambiar contenido del panel central
        btnPeliculas.addActionListener(e -> mostrarPanelPeliculas());
        btnSalas.addActionListener(e -> mostrarMensaje("Módulo de Salas"));
        btnFunciones.addActionListener(e -> mostrarMensaje("Módulo de Funciones"));
        btnReservas.addActionListener(e -> mostrarMensaje("Módulo de Reservas"));
        btnUsuarios.addActionListener(e -> mostrarMensaje("Módulo de Usuarios"));
    }
    
    private void mostrarPanelSalas() {
        panelCentral.removeAll();
        panelCentral.revalidate();
        panelCentral.repaint();
    }
    
    private void mostrarPanelPeliculas() {
        panelCentral.removeAll();
        panelCentral.add(new PanelPeliculas(), BorderLayout.CENTER);
        panelCentral.revalidate();
        panelCentral.repaint();
    }


    private void mostrarMensaje(String texto) {
        panelCentral.removeAll();
        panelCentral.add(new JLabel(texto, SwingConstants.CENTER), BorderLayout.CENTER);
        panelCentral.revalidate();
        panelCentral.repaint();
    }
}
